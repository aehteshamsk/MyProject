package testNG;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;

public class OrangeHRM_Parallel_Testing {
	WebDriver driver;
	public void url(WebDriver driver)
	 {
		 driver.get("https://opensource-demo.orangehrmlive.com/web/index.php/auth/login");
	 }
	 public void username(WebDriver driver, String usn)
	 {
		 driver.findElement(By.xpath("//input[@name='username']")).sendKeys(usn);
	 }
	 public void password(WebDriver driver, String pwd)
	 {
		 driver.findElement(By.xpath("//input[@type='password']")).sendKeys(pwd);
	 }
	 public void loginbutton(WebDriver driver)
	 {
		 driver.findElement(By.xpath("//button[@type='submit']")).click();
	 }
	 public void welcomeadmin(WebDriver driver)
	 {
		 driver.findElement(By.xpath("//span[@class='oxd-userdropdown-tab']")).click();	
	 }
	 public void logoutbutton(WebDriver driver)
	 {
		 driver.findElement(By.linkText("Logout")).click();
	 }
	 @BeforeTest
	  public void beforeTest() 
	 {
		 System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\chromedriver.exe");
		   driver= new ChromeDriver();
		   driver.manage().window().maximize();
		   driver.manage().deleteAllCookies();
	  }		
	@Test(description= "Parallel Testing")
	  public void OrangeHRM() throws InterruptedException 
	  {
		OrangeHRM_Parallel_Testing o= new OrangeHRM_Parallel_Testing();
		o.url(driver);
		Thread.sleep(2000);
		o.username(driver, "Admin");
		o.password(driver, "admin123");
		o.loginbutton(driver);
		Thread.sleep(2000);
		o.welcomeadmin(driver);
		Thread.sleep(2000);
		o.logoutbutton(driver);		
	  }
  @AfterTest
  public void afterTest() 
  {
	  driver.close();
  }

}
