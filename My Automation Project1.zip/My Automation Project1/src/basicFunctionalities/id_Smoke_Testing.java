package basicFunctionalities;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

public class Luma_Smoke_Testing {

	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
public void signin(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Sign")).click();  
		driver.findElement(By.id("email")).sendKeys("kumaripuja2359@gmail.com");
		Thread.sleep(2000);
		driver.findElement(By.id("pass")).sendKeys("Family@143");
		Thread.sleep(2000);
		driver.findElement(By.id("send2")).click();
		Thread.sleep(2000);
		driver.findElement(By.xpath("//a[@aria-label='store logo']//img")).click();
	}
public void welcomePujaKumari(WebDriver driver)
{
	 driver.findElement(By.xpath("//span[@aria-expanded='false']")).click();
}
public void signout(WebDriver driver)
{
	 driver.findElement(By.partialLinkText("Sign")).click();
}
	public static void main(String[] args) throws InterruptedException {
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\msedgedriver.exe");
		WebDriver driver= new EdgeDriver();

		Luma_Smoke_Testing l= new Luma_Smoke_Testing();
    		 l.url(driver);
	         l.maximize(driver);
	         l.cookies(driver);
	         Thread.sleep(2000);
	         l.signin(driver);
   
		//***Mouse_Hover***
    	Actions a= new Actions(driver);

    	List<WebElement> ls=  driver.findElements(By.xpath("//ul[@id='ui-id-2']/li"));
 
    	int size= ls.size();
    	System.out.println("No of Modules: "+size);
    	
    	for(int i= 1; i<=6; i++)
    	{
    		Thread.sleep(2000);
    		System.out.println(driver.findElement(By.xpath("//ul[@id='ui-id-2']/li["+i+"]")).getText());
    		a.moveToElement(driver.findElement(By.xpath("//ul[@id='ui-id-2']/li["+i+"]"))).click().perform();                 //Perform Monuse_Hover
    	}
   
    	l.welcomePujaKumari(driver);
    	Thread.sleep(2000);
    	l.signout(driver);
    	driver.close();

	}

}
