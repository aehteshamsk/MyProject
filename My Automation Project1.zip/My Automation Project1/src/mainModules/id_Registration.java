package mainModules;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.edge.EdgeDriver;

public class Luma_Registration {
	public void url(WebDriver driver)
	{
       driver.get("https://magento.softwaretestingboard.com");
	}
	public void maximize(WebDriver driver)
    {
	  driver.manage().window().maximize();
    }
	public void cookies(WebDriver driver)
	{
		driver.manage().deleteAllCookies();
	}
	public void newuser(WebDriver driver) throws InterruptedException
	{
		driver.findElement(By.partialLinkText("Create an")).click();
		driver.findElement(By.id("firstname")).sendKeys("Puja");
		//Thread.sleep(2000);
		driver.findElement(By.id("lastname")).sendKeys("Kumari");
		//Thread.sleep(2000);
		driver.findElement(By.id("email_address")).sendKeys("kumaripuja2359@gmail.com");
		//Thread.sleep(2000);
		driver.findElement(By.id("password")).sendKeys("Family@143");
		//Thread.sleep(2000);
		driver.findElement(By.id("password-confirmation")).sendKeys("Family@143");
	//	Thread.sleep(2000);
		driver.findElement(By.partialLinkText("Create an")).click();
	}
	public static void main(String[] args) throws Exception 
	{
		System.setProperty("webdriver.chrome.driver", "C:\\Users\\Admin Pc\\OneDrive\\Documents\\Automation Testing\\Browser Extension\\msedgedriver.exe");
        WebDriver driver =new EdgeDriver();
        
        Luma_Registration l= new  Luma_Registration();
        
        l.url(driver);
        l.maximize(driver);
        l.cookies(driver);
        Thread.sleep(2000);
        l.newuser(driver);

	}

}
